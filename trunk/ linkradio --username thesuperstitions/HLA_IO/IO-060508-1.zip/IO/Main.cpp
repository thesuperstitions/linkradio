/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: DefaultConfig
//!	Generated Date	: Mon, 19, May 2008  
	File Path	: DefaultComponent\DefaultConfig\MainDefaultComponent.cpp
*********************************************************************/

#include "Main.h"
#include "PublisherThread.h"
#include "SubscriberThread.h"
#include "FrameworkThread.h"

PublisherThread*    publisherThread;
SubscriberThread*   subscriberThread;
FrameworkThread*    frameworkThread;

//----------------------------------------------------------------------------
// MainDefaultComponent.cpp                                                                  
//----------------------------------------------------------------------------

//## configuration DefaultComponent::DefaultConfig 
int main(int argc, char* argv[]) 
{

  char c[5];
  int unitNumber = atoi(argv[1]);

  printf("Hit any key to CREATE Federate/Application");
  fgets(c, 2, stdin);

  frameworkThread = new FrameworkThread(unitNumber);

  publisherThread = new PublisherThread(unitNumber);

  subscriberThread = new SubscriberThread(unitNumber);

  subscriberThread->start();

  printf("Hit any key to START sending messages");
  fgets(c, 2, stdin);

  publisherThread->start();

  printf("Hit any key to STOP  queing/de-queing messages\n\n");
  fgets(c, 2, stdin);

  publisherThread->stop();

	delete publisherThread;

  subscriberThread->stop();

  delete subscriberThread;

  printf("Hit any key to EXIT\n\n");
  fgets(c, 2, stdin);

  delete frameworkThread;

  return 0;
}


/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\MainDefaultComponent.cpp
*********************************************************************/

