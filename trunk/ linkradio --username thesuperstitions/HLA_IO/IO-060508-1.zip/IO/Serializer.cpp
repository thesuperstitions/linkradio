/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: framework::Control::Serializer
//!	Generated Date	: Mon, 19, May 2008  
	File Path	: DefaultComponent\DefaultConfig\Serializer.cpp
*********************************************************************/

#include "Serializer.h"

//----------------------------------------------------------------------------
// Serializer.cpp                                                                  
//----------------------------------------------------------------------------

//## package framework::Control 

//## class Serializer 

namespace framework {
    namespace Control {
        
        Serializer::Serializer() {
        }
        
        Serializer::~Serializer() {
        }
        
    }
}


/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\Serializer.cpp
*********************************************************************/

