/********************************************************************
	Login		: rosskw1
	Model Element	: SubscriberThread
  Generated Date	: Mon, 21, Apr 2008

  Description: This class is based upon the "Thread" class.  It reads
  messages from a Queue, one at a time, and checks to make sure that
  the messages are received in sequence.
*********************************************************************/

#include "SubscriberThread.h"
#include <stdio.h>
#include <time.h>
#include <sys/timeb.h>
#include "Sleep.h"

//----------------------------------------------------------------------------
// SubscriberThread.cpp
//----------------------------------------------------------------------------

struct MessageStruct
{
  long MsgNumber;
  unsigned char MsgBody[96];
};


static timeb previousTime;


SubscriberThread::SubscriberThread(int unitNumber)
{
  char s[200];
  exitFlag = false;
  
  sprintf(s, "Unit%u-CEC_R49-Subscriber", unitNumber);
  myQueue = new framework::utils::InterprocessQueue(s, 1000, 1000);

  previousTime.time = 0;
  previousTime.millitm = 0;
}

SubscriberThread::~SubscriberThread()
{

  stop();

  delete myQueue;
}

void SubscriberThread::start()
{
  exitFlag = false;

  Thread::start();
}

void SubscriberThread::stop()
{
  exitFlag = true;

  this->Thread::join();

  Thread::stop();
}

void SubscriberThread::threadOperation()
{
  char           s[500];
  MessageStruct  gmsg;
  bool           timeoutFlag = true; // This forces a "Queue Synchronization" operation.
  unsigned int   msgCount = 0;
  long           prevMsgCount = -1;

while(myQueue->SynchronizeQueueUsers() == false);

  while(exitFlag == false)
  {
    if (timeoutFlag == true)
    {
      // The "getMessage" call timed-out.  We didn't get a message within our timeout limit.
      // Go through the Queue synchonization procedure.  This mimics what might be done in
      // a tactical system where a computer goes down and the interface protocol tries to
      // re-establish communications.
      LogMessage("Synching To Queue Partner\n");
      while(myQueue->SynchronizeQueueUsers() == false)
      {
        if (exitFlag == true)
          return;
      }
      timeoutFlag = false;
			LogMessage("Queue Synching Complete\n");
		}

    if (myQueue->timedGetMessage((unsigned char*)&gmsg, &msgCount, 1, 500000) == true)
    {

      if (gmsg.MsgNumber != (prevMsgCount+1))
      {
        //sprintf(s, "PROBLEM!!! - MsgNumber=%u, PrevMsgNum=%u\n", gmsg.MsgNumber, prevMsgCount);
        //LogMessage(s);
      }

      //if ((msgCount % 100000) == 0)
      //{
      sprintf(s, "Subscriber::threadOps - Msg Number=%u, #Bytes=%u\n\n", gmsg.MsgNumber, msgCount);
        LogMessage(s);
      //}
      prevMsgCount = msgCount;
    }
    else
    {
      LogMessage("TIMEOUT\n");
      timeoutFlag = true;
    }
  };



}



        void SubscriberThread::LogMessage(char* Msg)
        {
          struct timeb  t;
          int           Hours, Mins, Secs;

          ftime(&t);
          Secs = t.time % 86400; // 86400 = Seconds/24 hours
          Hours = Secs / 3600;
          Secs -= Hours * 3600;
          Mins = Secs / 60;
          Secs -= Mins * 60;

          //TS = gmtime( &tt );
          printf("%02u:%02u:%02u.%03u : %s", Hours, Mins, Secs, t.millitm, Msg);
        }
/*********************************************************************
	SubscriberThread.cpp
*********************************************************************/

