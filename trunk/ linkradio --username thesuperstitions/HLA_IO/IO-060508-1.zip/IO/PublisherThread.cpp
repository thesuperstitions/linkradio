/********************************************************************
	Login		: rosskw1
	Model Element	: PublisherThread
	Generated Date	: Mon, 21, Apr 2008
	File Path	: PublisherThread.cpp

  Description: This class is based upon the "Thread" class.  It
  generates messages that get queued for consumption by the
  "consumerThread".

*********************************************************************/

#include "PublisherThread.h"

#include "Sleep.h"
#include <sys/timeb.h>

static long msgCount = 0;

//#define MAX_MSG_COUNT 1048576

//----------------------------------------------------------------------------
// PublisherThread.cpp
//----------------------------------------------------------------------------

//## class PublisherThread

struct MessageStruct
{
  long          MsgNumber;
  unsigned char MsgBody[96];
};

PublisherThread::PublisherThread(int unitNumber)
{
  char s[200];
  exitFlag = false;
  
  sprintf(s, "Unit%u-CEC_R49-Publisher", unitNumber);
  myQueue = new framework::utils::InterprocessQueue(s, 1000, 1000);
}

PublisherThread::~PublisherThread()
{

  stop();

  delete myQueue;

}

void PublisherThread::start()
{
  exitFlag = false;

  Thread::start();
}

void PublisherThread::stop()
{
  exitFlag = true;

  this->Thread::join();
  Thread::stop();
}


void PublisherThread::threadOperation()
{
  MessageStruct msg;
  unsigned int  slot = 0;
  bool          timeoutFlag = true; // This forces a "Queue Synchronization" operation.

while(myQueue->SynchronizeQueueUsers() == false);

  while(exitFlag == false)
  {
		if ((timeoutFlag == true) || (myQueue->getQueueState() == framework::utils::InterprocessQueue::QueueSynchronizing))
    {// The "getMessage" call timed-out.  We didn't get a message within our timeout limit.
      // Go through the Queue synchonization procedure.  This mimics what might be done in
      // a tactical system where a computer goes down and the interface protocol tries to
      // re-establish communications.
      LogMessage("PublisherThread::threadOperation - Synching To Queue Partner\n");
      while(myQueue->SynchronizeQueueUsers() == false)
      {
        if (exitFlag == true)
          return;
      }
      timeoutFlag = false;
			LogMessage("Publisher::threadOps  - Queue Synching Complete\n");
		}

    msg.MsgNumber = msgCount++;
//    msg.MsgNumber = 0xAABBCCDD;
//    LogMessage("PublisherThread::threadOperation - Sending Message\n");
    if (myQueue->timedAddMessage((unsigned char*)&msg, sizeof(MessageStruct), 0, 500000) == false)
      timeoutFlag = true;
    else
    {
//      LogMessage("PublisherThread::threadOperation - Sleeping\n");
      framework::utils::Sleep::sleep(1, 0/*250000000*/);
    }
  };
}







        void PublisherThread::LogMessage(char* Msg)
        {
          struct timeb  t;
          int           Hours, Mins, Secs;

          ftime(&t);
          Secs = t.time % 86400; // 86400 = Seconds/24 hours
          Hours = Secs / 3600;
          Secs -= Hours * 3600;
          Mins = Secs / 60;
          Secs -= Mins * 60;

          //TS = gmtime( &tt );
          printf("%02u:%02u:%02u.%03u : %s", Hours, Mins, Secs, t.millitm, Msg);
        }


/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\PublisherThread.cpp
*********************************************************************/

