/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: framework::IO
//!	Generated Date	: Tue, 20, May 2008  
	File Path	: DefaultComponent\DefaultConfig\IO.cpp
*********************************************************************/

#include "IO.h"
#include "C_IO_Functions.h"
#include "FederateInterface.h"
#include "FederateIO_Handler.h"
#include "HLA_FederateInterface.h"
#include "HLA_PostOffice.h"
#include "OASIS_FederateInterface.h"
#include "PostOffice.h"

//----------------------------------------------------------------------------
// IO.cpp                                                                  
//----------------------------------------------------------------------------

//## package framework::IO 

namespace framework {
    namespace IO {
        
    }
}

namespace framework {
    namespace IO {
        
        
        
    }
}

/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\IO.cpp
*********************************************************************/

