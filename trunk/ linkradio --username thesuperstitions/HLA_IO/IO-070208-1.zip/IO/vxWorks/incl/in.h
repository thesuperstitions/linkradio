/* in.h - obsolete vxWorks 5.0 header file */


/*
modification history
--------------------
01c,29sep92,rrr  changed name of __INCinh to avoid conflict
01b,22sep92,rrr  added support for c++
01a,19sep92,smb  written for compatibility with 5.0
*/

#include <netinet/in.h>
