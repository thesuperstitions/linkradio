#ifndef SC_glob_H
#define SC_glob_H

#include <softwareClock.h>

#ifdef  __cplusplus
extern "C" {
#endif

extern SoftwareClock globSoftwareClock;

#ifdef  __cplusplus
}
#endif

#endif
