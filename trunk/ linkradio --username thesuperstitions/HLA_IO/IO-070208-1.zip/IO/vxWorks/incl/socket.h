/* socket.h - obsolete vxWorks 5.0 header file */


/*
modification history
--------------------
01a,09feb93,rrr  written for compatibility with 5.0
*/

#include <sys/socket.h>
