/* stdioLib.h - obsolete vxWorks 5.0 header file */


/*
modification history
--------------------
01b,22sep92,rrr  added support for c++
01a,19sep92,smb  written for compatibility with 5.0
*/

#ifndef STDIO_LIB_H
#define STDIO_LIB_H

#include <stdio.h>
#include <string.h>
#include <strings.h>

#ifdef	__cplusplus
extern "C" {
#endif

#ifdef	__cplusplus
}
#endif

#endif
