static char mware_revision[] = "$Header:";
