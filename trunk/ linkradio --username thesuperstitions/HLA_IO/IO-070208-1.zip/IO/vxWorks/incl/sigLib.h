/* sigLib.h - obsolete vxWorks 5.0 header file */


/*
modification history
--------------------
01f,09feb93,rrr  added SIGCONTEXT typedef for compatibility with 5.0.
01e,05feb93,rrr  fixed spr 1906 (signal numbers to match sun os)
01d,22sep92,rrr  added support for c++
01c,21sep92,rrr  more stuff to be more like 5.0.
01a,20sep92,smb  changed signalP.h to sigLibP.h
01a,19sep92,jcf  written for compatibility with 5.0.
*/

#include <signal.h>
