/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: RtiAmbassadorObject
//!	Generated Date	: Thu, 21, Feb 2008  
	File Path	: DefaultComponent\DefaultConfig\RtiAmbassadorObject.cpp
*********************************************************************/

#include "RtiAmbassadorObject.h"

//----------------------------------------------------------------------------
// RtiAmbassadorObject.cpp                                                                  
//----------------------------------------------------------------------------

//## package FrameworkTest 

//## class RtiAmbassadorObject 


RtiAmbassadorObject::RtiAmbassadorObject() {
}

RtiAmbassadorObject::~RtiAmbassadorObject() {
}



/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\RtiAmbassadorObject.cpp
*********************************************************************/

