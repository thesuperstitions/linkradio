/*********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: thread
//!	Generated Date	: Wed, 2, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\thread.h
*********************************************************************/


#ifndef thread_H 

#define thread_H 

// dependency config 
#include <boost\thread\detail\config.hpp>
// dependency utility 
#include <boost\utility.hpp>
// dependency function 
#include <boost\function.hpp>
// dependency mutex 
#include <boost\thread\mutex.hpp>
// dependency list 
#include <list>
// dependency memory 
#include <memory>

//----------------------------------------------------------------------------
// thread.h                                                                  
//----------------------------------------------------------------------------



#endif  
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\thread.h
*********************************************************************/

