/*********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: mutex
//!	Generated Date	: Wed, 2, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\mutex.h
*********************************************************************/


#ifndef mutex_H 

#define mutex_H 

// dependency config 
#include <boost\thread\detail\config.hpp>
// dependency utility 
#include <boost\utility.hpp>
// dependency lock 
#include <boost\thread\detail\lock.hpp>

//----------------------------------------------------------------------------
// mutex.h                                                                  
//----------------------------------------------------------------------------


namespace boost {
    //#[ dependency xtime 
    struct xtime;
    //#]
    
    
}




#endif  
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\mutex.h
*********************************************************************/

