/*********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: ReverseEngineering
//!	Generated Date	: Wed, 2, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\ReverseEngineering.h
*********************************************************************/


#ifndef ReverseEngineering_H 

#define ReverseEngineering_H 

#include <oxf/oxf.h>
#include <string>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <iostream>
#include "Configuration.h"
#include "RTI\RTI1516.h"

//----------------------------------------------------------------------------
// ReverseEngineering.h                                                                  
//----------------------------------------------------------------------------

//## package ReverseEngineering 

#ifdef _MSC_VER
// disable Microsoft compiler warning (debug information truncated)
#pragma warning(disable: 4786)
#endif


//## attribute __MUTEX_LOCK_H 
#define __MUTEX_LOCK_H 

//## attribute __MUTEX__H 
#define __MUTEX__H 



#endif  
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\ReverseEngineering.h
*********************************************************************/

