/*********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: RtiAmbassadorObject
//!	Generated Date	: Thu, 21, Feb 2008  
	File Path	: DefaultComponent\DefaultConfig\RtiAmbassadorObject.h
*********************************************************************/


#ifndef RtiAmbassadorObject_H 

#define RtiAmbassadorObject_H 

#include <oxf/oxf.h>
#include <string>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <iostream>
#include "Configuration.h"
#include "RTI\RTI1516.h"

//----------------------------------------------------------------------------
// RtiAmbassadorObject.h                                                                  
//----------------------------------------------------------------------------

//## package FrameworkTest 

#ifdef _MSC_VER
// disable Microsoft compiler warning (debug information truncated)
#pragma warning(disable: 4786)
#endif

//## class RtiAmbassadorObject 
class RtiAmbassadorObject  {


////    Constructors and destructors    ////
public :
    
    //## auto_generated 
    RtiAmbassadorObject();
    
    //## auto_generated 
    ~RtiAmbassadorObject();


};


#endif  
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\RtiAmbassadorObject.h
*********************************************************************/

