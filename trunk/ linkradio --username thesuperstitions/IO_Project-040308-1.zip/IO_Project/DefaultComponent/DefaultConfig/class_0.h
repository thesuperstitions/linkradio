/*********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: boost::class_0
//!	Generated Date	: Wed, 2, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\class_0.h
*********************************************************************/


#ifndef class_0_H 

#define class_0_H 

#include <oxf/oxf.h>
#include <string>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <iostream>
#include "Configuration.h"
#include "RTI\RTI1516.h"
#include "boost.h"

//----------------------------------------------------------------------------
// class_0.h                                                                  
//----------------------------------------------------------------------------

//## package boost 

#ifdef _MSC_VER
// disable Microsoft compiler warning (debug information truncated)
#pragma warning(disable: 4786)
#endif

namespace boost {
    //## class class_0 
    class class_0  {
    
    
    ////    Constructors and destructors    ////
    public :
        
        //## auto_generated 
        class_0();
        
        //## auto_generated 
        ~class_0();
    
    
    };
}


#endif  
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\class_0.h
*********************************************************************/

