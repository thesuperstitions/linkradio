/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: DefaultConfig
//!	Generated Date	: Fri, 15, Feb 2008  
	File Path	: DefaultComponent\DefaultConfig\MainDefaultComponent.cpp
*********************************************************************/

#include "MainDefaultComponent.h"

//----------------------------------------------------------------------------
// MainDefaultComponent.cpp                                                                  
//----------------------------------------------------------------------------

//## configuration DefaultComponent::DefaultConfig 
int main(int argc, char* argv[]) {
    if(OXF::initialize(argc, argv, 6423))
        {
            //#[ configuration DefaultComponent::DefaultConfig 
            //#]
            OXF::start();
            return 0;
        }
    else
        {
            return 1;
        }
}


/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\MainDefaultComponent.cpp
*********************************************************************/

