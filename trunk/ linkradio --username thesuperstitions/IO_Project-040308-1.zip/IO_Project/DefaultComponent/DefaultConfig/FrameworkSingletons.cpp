/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: FrameworkSingletons
//!	Generated Date	: Wed, 20, Feb 2008  
	File Path	: DefaultComponent\DefaultConfig\FrameworkSingletons.cpp
*********************************************************************/

#include "FrameworkSingletons.h"

//----------------------------------------------------------------------------
// FrameworkSingletons.cpp                                                                  
//----------------------------------------------------------------------------

//## package FrameworkSingletons 



//## auto_generated 
FrameworkFederateAmbassador getTheFrameworkFederateAmbassador() {
    return theFrameworkFederateAmbassador;
}

//## auto_generated 
void setTheFrameworkFederateAmbassador(FrameworkFederateAmbassador p_theFrameworkFederateAmbassador) {
    theFrameworkFederateAmbassador = p_theFrameworkFederateAmbassador;
}

//## attribute Federate_1 
static Framework::Control::Federate(HLA_FederateFrameworkType, CEC) Federate_1;

//## attribute Federate_2 
static Framework::Control::Federate(HLA_FederateFrameworkType, SSDS) Federate_2;

//## attribute theFederateInterfaceFactory 
static FederateInterfaceFactory(HLA_FederateFrameworkType) theFederateInterfaceFactory;

//## attribute theFrameworkFederateAmbassador 
static FrameworkFederateAmbassador theFrameworkFederateAmbassador( NULL );

//## attribute thePostOffice 
static Framework::IO::HLA_PostOffice thePostOffice;

//## attribute theRtiAmbassador 
static Framework::RtiAmbassador theRtiAmbassador;


/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\FrameworkSingletons.cpp
*********************************************************************/

