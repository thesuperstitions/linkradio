/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: boost
//!	Generated Date	: Wed, 2, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\boost.cpp
*********************************************************************/

#include "boost.h"

//----------------------------------------------------------------------------
// boost.cpp                                                                  
//----------------------------------------------------------------------------

//## package boost 

namespace boost {
    
}

namespace boost {
    
    
}

/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\boost.cpp
*********************************************************************/

