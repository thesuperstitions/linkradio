/*********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: boost
//!	Generated Date	: Wed, 2, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\boost.h
*********************************************************************/


#ifndef boost_H 

#define boost_H 

#include <oxf/oxf.h>
#include <string>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <iostream>
#include "Configuration.h"
#include "RTI\RTI1516.h"

//----------------------------------------------------------------------------
// boost.h                                                                  
//----------------------------------------------------------------------------

//## package boost 

#ifdef _MSC_VER
// disable Microsoft compiler warning (debug information truncated)
#pragma warning(disable: 4786)
#endif


namespace boost {
    
    //## type xtime 
    struct xtime {};
    
    
    
}


#endif  
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\boost.h
*********************************************************************/

