/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: boost::class_0
//!	Generated Date	: Wed, 2, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\class_0.cpp
*********************************************************************/

#include "class_0.h"

//----------------------------------------------------------------------------
// class_0.cpp                                                                  
//----------------------------------------------------------------------------

//## package boost 

//## class class_0 

namespace boost {
    
    class_0::class_0() {
    }
    
    class_0::~class_0() {
    }
    
}


/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\class_0.cpp
*********************************************************************/

