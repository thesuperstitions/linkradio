/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Framework::Utilities
//!	Generated Date	: Fri, 15, Feb 2008  
	File Path	: DefaultComponent\DefaultConfig\Utilities.cpp
*********************************************************************/

#include "Utilities.h"

//----------------------------------------------------------------------------
// Utilities.cpp                                                                  
//----------------------------------------------------------------------------

//## package Framework 

//## class Utilities 

namespace Framework {
    
    Utilities::Utilities() {
    }
    
    Utilities::~Utilities() {
    }
    
}


/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\Utilities.cpp
*********************************************************************/

