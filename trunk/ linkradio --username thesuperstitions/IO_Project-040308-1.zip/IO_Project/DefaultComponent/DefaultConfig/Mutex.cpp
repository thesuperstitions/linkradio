/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Framework::Mutex
//!	Generated Date	: Wed, 2, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\Mutex.cpp
*********************************************************************/

#include "Mutex.h"

//----------------------------------------------------------------------------
// Mutex.cpp                                                                  
//----------------------------------------------------------------------------

//## package Framework 

//## class Mutex 

namespace Framework {
    
    
    
}


/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\Mutex.cpp
*********************************************************************/

