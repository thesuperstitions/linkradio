/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Framework::IO::FederateIO_Handler
//!	Generated Date	: Wed, 2, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\FederateIO_Handler.cpp
*********************************************************************/

#include "FederateIO_Handler.h"
// link itsFederateInterfaceFactory 
#include "FederateInterfaceFactory.h"
#include "Serializer.h"
// link itsFederateIO_Thread 
#include "FederateIO_Thread.h"
// dependency PostOffice 
#include "PostOffice.h"

//----------------------------------------------------------------------------
// FederateIO_Handler.cpp                                                                  
//----------------------------------------------------------------------------

//## package Framework::IO 

//## class FederateIO_Handler 

namespace Framework {
    namespace IO {
        
        
        FederateIO_Handler::FederateIO_Handler(Framework::InterfaceType interfaceType, FederateFrameworkType frameworkType) : frameworkType(frameworkType), interfaceType(interfaceType) ,itsFederateInterface() ,itsFederateMessage() {
            itsFederateInterfaceFactory = NULL;
            itsFederateIO_Thread = NULL;
            //#[ operation FederateIO_Handler(Framework::InterfaceType,FederateFrameworkType) 
            
            setItsFederateInterfaceFactory( new Framework::Control::FederateInterfaceFactory(frameworkType) ); 
            
            // Spin off a thread to handle output of Federate Messages.
            setItsFederateIO_Thread( new  FederateIO_Thread() );
            getItsFederateIO_Thread()->setItsFederateIO_Handler(this);
            getItsFederateIO_Thread()->start();
            //#]
        }
        
        FederateIO_Handler::FederateIO_Handler() : itsFederateInterface() ,itsFederateMessage() {
            itsFederateIO_Thread = NULL;
            itsFederateInterfaceFactory = NULL;
        }
        
        FederateIO_Handler::~FederateIO_Handler() {
            cleanUpRelations();
        }
        
        void FederateIO_Handler::createFederateInterface(std::string interfaceName) {
            //#[ operation createFederateInterface(std::string) 
              
            // Create a FederateInterface by calling the factory.
            Framework::IO::FederateInterface* FI_Ptr = getItsFederateInterfaceFactory()->createFederateInterface(interfaceName, interfaceType);
                        
            // Map the Federate interface to its name.
            addItsFederateInterface(interfaceName, FI_Ptr);   
            
            // Set the Federate Interface' link to the this FederateIO_Handler.
            FI_Ptr->setItsFederateIO_Handler(this);
            
            Framework::Control::getPostOffice()->announcePublication( getItsFederateInterface(interfaceName));   
             
            Framework::Control::getPostOffice()->announceSubscription( getItsFederateInterface(interfaceName) );   
            
            //#]
        }
        
        void FederateIO_Handler::recvMessage(FederateMessage* message) {
            //#[ operation recvMessage(FederateMessage*) 
            //#]
        }
        
        void FederateIO_Handler::sendMessage(std::string interfaceName, char* message, int messageSizeInBytes) {
            //#[ operation sendMessage(std::string,char*,int) 
            
            Framework::IO::FederateInterface* fi_Ptr = getItsFederateInterface(interfaceName);
            
            // Serialize the message data.  
            message = Framework::IO::serializer( getMessageType( message, fi_Ptr->getInterfaceType() ), message);
            
            // Create a FederateMessage instance and populate it.
            FederateMessage* fm_Ptr = new FederateMessage( fi_Ptr, message, messageSizeInBytes );
            
            // Add this FederateMessage to the outgoing list of messages
            getItsFederateIO_Thread()->addItsFederateMessage(fm_Ptr);
            
            //#]
        }
        
        FederateFrameworkType FederateIO_Handler::getFrameworkType() const {
            return frameworkType;
        }
        
        void FederateIO_Handler::setFrameworkType(FederateFrameworkType p_frameworkType) {
            frameworkType = p_frameworkType;
        }
        
        Framework::InterfaceType FederateIO_Handler::getInterfaceType() const {
            return interfaceType;
        }
        
        void FederateIO_Handler::setInterfaceType(Framework::InterfaceType p_interfaceType) {
            interfaceType = p_interfaceType;
        }
        
        Framework::IO::FederateIO_Thread* FederateIO_Handler::getItsFederateIO_Thread() const {
            return itsFederateIO_Thread;
        }
        
        void FederateIO_Handler::__setItsFederateIO_Thread(Framework::IO::FederateIO_Thread* p_FederateIO_Thread) {
            itsFederateIO_Thread = p_FederateIO_Thread;
        }
        
        void FederateIO_Handler::_setItsFederateIO_Thread(Framework::IO::FederateIO_Thread* p_FederateIO_Thread) {
            if(itsFederateIO_Thread != NULL)
                {
                    itsFederateIO_Thread->__setItsFederateIO_Handler(NULL);
                }
            __setItsFederateIO_Thread(p_FederateIO_Thread);
        }
        
        void FederateIO_Handler::setItsFederateIO_Thread(Framework::IO::FederateIO_Thread* p_FederateIO_Thread) {
            if(p_FederateIO_Thread != NULL)
                {
                    p_FederateIO_Thread->_setItsFederateIO_Handler(this);
                }
            _setItsFederateIO_Thread(p_FederateIO_Thread);
        }
        
        void FederateIO_Handler::_clearItsFederateIO_Thread() {
            itsFederateIO_Thread = NULL;
        }
        
        std::map<std::string, Framework::IO::FederateInterface*>::const_iterator FederateIO_Handler::getItsFederateInterface() const {
            std::map<std::string, Framework::IO::FederateInterface*>::const_iterator iter;
            iter = itsFederateInterface.begin();
            return iter;
        }
        
        std::map<std::string, Framework::IO::FederateInterface*>::const_iterator FederateIO_Handler::getItsFederateInterfaceEnd() const {
            return itsFederateInterface.end();
        }
        
        void FederateIO_Handler::_clearItsFederateInterface() {
            itsFederateInterface.clear();
        }
        
        void FederateIO_Handler::clearItsFederateInterface() {
            std::map<std::string, Framework::IO::FederateInterface*>::const_iterator iter;
            iter = itsFederateInterface.begin();
            while (iter != itsFederateInterface.end()){
                ((*iter).second)->_clearItsFederateIO_Handler();
                iter++;
            }
            _clearItsFederateInterface();
        }
        
        void FederateIO_Handler::_removeItsFederateInterface(Framework::IO::FederateInterface* p_FederateInterface) {
            std::map<std::string, Framework::IO::FederateInterface*>::iterator pos = std::find_if(itsFederateInterface.begin(), itsFederateInterface.end(),OMValueCompare<const std::string,Framework::IO::FederateInterface*>(p_FederateInterface));
            if (pos != itsFederateInterface.end()) {
            	itsFederateInterface.erase(pos);
            }
        }
        
        void FederateIO_Handler::removeItsFederateInterface(Framework::IO::FederateInterface* p_FederateInterface) {
            if(p_FederateInterface != NULL)
                {
                    p_FederateInterface->__setItsFederateIO_Handler(NULL);
                }
            _removeItsFederateInterface(p_FederateInterface);
        }
        
        Framework::IO::FederateInterface* FederateIO_Handler::getItsFederateInterface(std::string key) const {
            return (itsFederateInterface.find(key) != itsFederateInterface.end() ? (*itsFederateInterface.find(key)).second : NULL);
        }
        
        void FederateIO_Handler::_addItsFederateInterface(std::string key, Framework::IO::FederateInterface* p_FederateInterface) {
            itsFederateInterface.insert(std::map<std::string, Framework::IO::FederateInterface*>::value_type(key, p_FederateInterface));
        }
        
        void FederateIO_Handler::addItsFederateInterface(std::string key, Framework::IO::FederateInterface* p_FederateInterface) {
            if(p_FederateInterface != NULL)
                {
                    p_FederateInterface->_setItsFederateIO_Handler(this);
                }
            _addItsFederateInterface(key, p_FederateInterface);
        }
        
        void FederateIO_Handler::_removeItsFederateInterface(std::string key) {
            itsFederateInterface.erase(key);
        }
        
        void FederateIO_Handler::removeItsFederateInterface(std::string key) {
            Framework::IO::FederateInterface* p_FederateInterface = getItsFederateInterface(key);
            if(p_FederateInterface != NULL)
                {
                    p_FederateInterface->_setItsFederateIO_Handler(NULL);
                }
            _removeItsFederateInterface(key);
        }
        
        Framework::Control::FederateInterfaceFactory* FederateIO_Handler::getItsFederateInterfaceFactory() const {
            return itsFederateInterfaceFactory;
        }
        
        void FederateIO_Handler::setItsFederateInterfaceFactory(Framework::Control::FederateInterfaceFactory* p_FederateInterfaceFactory) {
            itsFederateInterfaceFactory = p_FederateInterfaceFactory;
        }
        
        std::map<FederateInterface*, Framework::IO::FederateMessage*>::const_iterator FederateIO_Handler::getItsFederateMessage() const {
            std::map<FederateInterface*, Framework::IO::FederateMessage*>::const_iterator iter;
            iter = itsFederateMessage.begin();
            return iter;
        }
        
        std::map<FederateInterface*, Framework::IO::FederateMessage*>::const_iterator FederateIO_Handler::getItsFederateMessageEnd() const {
            return itsFederateMessage.end();
        }
        
        void FederateIO_Handler::clearItsFederateMessage() {
            itsFederateMessage.clear();
        }
        
        void FederateIO_Handler::removeItsFederateMessage(Framework::IO::FederateMessage* p_FederateMessage) {
            std::map<FederateInterface*, Framework::IO::FederateMessage*>::iterator pos = std::find_if(itsFederateMessage.begin(), itsFederateMessage.end(),OMValueCompare<const FederateInterface*,Framework::IO::FederateMessage*>(p_FederateMessage));
            if (pos != itsFederateMessage.end()) {
            	itsFederateMessage.erase(pos);
            }
        }
        
        Framework::IO::FederateMessage* FederateIO_Handler::getItsFederateMessage(FederateInterface* key) const {
            return (itsFederateMessage.find(key) != itsFederateMessage.end() ? (*itsFederateMessage.find(key)).second : NULL);
        }
        
        void FederateIO_Handler::addItsFederateMessage(FederateInterface* key, Framework::IO::FederateMessage* p_FederateMessage) {
            itsFederateMessage.insert(std::map<FederateInterface*, Framework::IO::FederateMessage*>::value_type(key, p_FederateMessage));
        }
        
        void FederateIO_Handler::removeItsFederateMessage(FederateInterface* key) {
            itsFederateMessage.erase(key);
        }
        
        void FederateIO_Handler::cleanUpRelations() {
            if(itsFederateIO_Thread != NULL)
                {
                    Framework::IO::FederateIO_Handler* p_FederateIO_Handler = itsFederateIO_Thread->getItsFederateIO_Handler();
                    if(p_FederateIO_Handler != NULL)
                        {
                            itsFederateIO_Thread->__setItsFederateIO_Handler(NULL);
                        }
                    itsFederateIO_Thread = NULL;
                }
            {
                std::map<std::string, Framework::IO::FederateInterface*>::const_iterator iter;
                iter = itsFederateInterface.begin();
                while (iter != itsFederateInterface.end()){
                    Framework::IO::FederateIO_Handler* p_FederateIO_Handler = ((*iter).second)->getItsFederateIO_Handler();
                    if(p_FederateIO_Handler != NULL)
                        {
                            ((*iter).second)->__setItsFederateIO_Handler(NULL);
                        }
                    iter++;
                }
                itsFederateInterface.clear();
            }
            if(itsFederateInterfaceFactory != NULL)
                {
                    itsFederateInterfaceFactory = NULL;
                }
            {
                itsFederateMessage.clear();
            }
        }
        
    }
}


/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\FederateIO_Handler.cpp
*********************************************************************/

