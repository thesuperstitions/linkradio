/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Framework::Control::Federate
//!	Generated Date	: Tue, 1, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\Federate.cpp
*********************************************************************/

#include "Federate.h"
// dependency FederateInterfaceFactory 
#include "FederateInterfaceFactory.h"
// operation Federate(FederateFrameworkType,FederateType,FrameworkFederateAmbassador*) 
#include "FrameworkFederateAmbassador.h"
// dependency HLA_PostOffice 
#include "HLA_PostOffice.h"
// dependency PostOffice 
#include "PostOffice.h"

//----------------------------------------------------------------------------
// Federate.cpp                                                                  
//----------------------------------------------------------------------------

//## package Framework::Control 

//## class Federate 

namespace Framework {
    namespace Control {
        
        
        Federate::Federate(FederateFrameworkType fedFrameworkType, FederateType fedType, FrameworkFederateAmbassador* frameworkFederateAmbassador) {
            thePostOffice = NULL;
            //#[ operation Federate(FederateFrameworkType,FederateType,FrameworkFederateAmbassador*) 
            
            setFederateFrameworkType(fedFrameworkType);
            setFederateType(fedType);
            
            switch(fedFrameworkType)
            {
              case HLA_FederateFrameworkType :  
                setThePostOffice( static_cast<Framework::IO::PostOffice*>(new Framework::IO::HLA_PostOffice(frameworkFederateAmbassador)) );  
              	break;
                
              case OASIS_FederateFrameworkType :    
            //    setThePostOffice( static_cast<Framework::IO::PostOffice>(new Framework::IO::OASIS_PostOffice()) );
                break;
            }; 
            thePostOffice->setTheFederate(this);  
            
            //#]
        }
        
        Federate::~Federate() {
            cleanUpRelations();
        }
        
        FederateFrameworkType Federate::getFederateFrameworkType() const {
            return federateFrameworkType;
        }
        
        void Federate::setFederateFrameworkType(FederateFrameworkType p_federateFrameworkType) {
            federateFrameworkType = p_federateFrameworkType;
        }
        
        FederateInterfaceFactory* Federate::getFederateInterfaceFactory() const {
            return federateInterfaceFactory;
        }
        
        void Federate::setFederateInterfaceFactory(FederateInterfaceFactory* p_federateInterfaceFactory) {
            federateInterfaceFactory = p_federateInterfaceFactory;
        }
        
        int Federate::getFederateType() const {
            return federateType;
        }
        
        void Federate::setFederateType(int p_federateType) {
            federateType = p_federateType;
        }
        
        Framework::IO::PostOffice* Federate::getThePostOffice() const {
            return thePostOffice;
        }
        
        void Federate::__setThePostOffice(Framework::IO::PostOffice* p_PostOffice) {
            thePostOffice = p_PostOffice;
        }
        
        void Federate::_setThePostOffice(Framework::IO::PostOffice* p_PostOffice) {
            if(thePostOffice != NULL)
                {
                    thePostOffice->__setTheFederate(NULL);
                }
            __setThePostOffice(p_PostOffice);
        }
        
        void Federate::setThePostOffice(Framework::IO::PostOffice* p_PostOffice) {
            if(p_PostOffice != NULL)
                {
                    p_PostOffice->_setTheFederate(this);
                }
            _setThePostOffice(p_PostOffice);
        }
        
        void Federate::_clearThePostOffice() {
            thePostOffice = NULL;
        }
        
        void Federate::cleanUpRelations() {
            if(thePostOffice != NULL)
                {
                    Framework::Control::Federate* p_Federate = thePostOffice->getTheFederate();
                    if(p_Federate != NULL)
                        {
                            thePostOffice->__setTheFederate(NULL);
                        }
                    thePostOffice = NULL;
                }
        }
        
    }
}


/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\Federate.cpp
*********************************************************************/

