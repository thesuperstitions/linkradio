/*********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Framework::MutexLock
//!	Generated Date	: Wed, 2, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\MutexLock.h
*********************************************************************/


#ifndef MutexLock_H 

#define MutexLock_H 

#include <oxf/oxf.h>
#include <string>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <iostream>
#include "Configuration.h"
#include "RTI\RTI1516.h"
#include "Framework.h"

//----------------------------------------------------------------------------
// MutexLock.h                                                                  
//----------------------------------------------------------------------------

class Mutex;

//## package Framework 

#ifdef _MSC_VER
// disable Microsoft compiler warning (debug information truncated)
#pragma warning(disable: 4786)
#endif

namespace Framework {
    //## class MutexLock 
    class MutexLock  {
    
    
    ////    Constructors and destructors    ////
    public :
        
        //## operation MutexLock(Mutex &) 
        MutexLock(Mutex & mutex) : lock(mutex.mutex)  {
            //#[ operation MutexLock(Mutex &) 
            //#]
        }
        
        
        //## operation ~MutexLock() 
        ~MutexLock() {
            //#[ operation ~MutexLock() 
            //#]
        }
        
    
    protected :
        
        //## operation MutexLock(const MutexLock &) 
        MutexLock(const MutexLock & arg1);
    
    
    ////    Operations    ////
    protected :
        
        //## operation operator=(const MutexLock &) 
        MutexLock &  operator=(const MutexLock & arg1);
    
    
    ////    Attributes    ////
    private :
        
        boost::mutex::scoped_lock lock;		//## attribute lock 
        
    
    };
}


#endif  
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\MutexLock.h
*********************************************************************/

