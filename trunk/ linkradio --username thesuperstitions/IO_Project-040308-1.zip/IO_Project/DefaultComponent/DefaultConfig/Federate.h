/*********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Framework::Control::Federate
//!	Generated Date	: Tue, 1, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\Federate.h
*********************************************************************/


#ifndef Federate_H 

#define Federate_H 

#include <oxf/oxf.h>
#include <string>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <iostream>
#include "Configuration.h"
#include "RTI\RTI1516.h"
#include "Control.h"
// operation Federate(FederateFrameworkType,FederateType,FrameworkFederateAmbassador*) 
#include "Framework.h"
// dependency FederateIO_Handler 
#include "FederateIO_Handler.h"

//----------------------------------------------------------------------------
// Federate.h                                                                  
//----------------------------------------------------------------------------


namespace Framework {
    
    namespace Control {
        class FederateInterfaceFactory;
        
    } 
    
} 

namespace Framework {
    class FrameworkFederateAmbassador;
    
} 

namespace Framework {
    
    namespace IO {
        class HLA_PostOffice;
        class PostOffice;
    }
    
}


//## package Framework::Control 

#ifdef _MSC_VER
// disable Microsoft compiler warning (debug information truncated)
#pragma warning(disable: 4786)
#endif

namespace Framework {
    namespace Control {
        //## class Federate 
        class Federate  {
        
        
        ////    Constructors and destructors    ////
        public :
            
            //## operation Federate(FederateFrameworkType,FederateType,FrameworkFederateAmbassador*) 
            Federate(FederateFrameworkType fedFrameworkType, FederateType fedType, FrameworkFederateAmbassador* frameworkFederateAmbassador);
            
            //## auto_generated 
            ~Federate();
        
        
        ////    Additional operations    ////
        public :
            
            //## auto_generated 
            IO::PostOffice* getThePostOffice() const;
            
            //## auto_generated 
            void setThePostOffice(IO::PostOffice* p_PostOffice);
        
        protected :
            
            //## auto_generated 
            FederateFrameworkType getFederateFrameworkType() const;
            
            //## auto_generated 
            void setFederateFrameworkType(FederateFrameworkType p_federateFrameworkType);
            
            //## auto_generated 
            FederateInterfaceFactory* getFederateInterfaceFactory() const;
            
            //## auto_generated 
            void setFederateInterfaceFactory(FederateInterfaceFactory* p_federateInterfaceFactory);
            
            //## auto_generated 
            int getFederateType() const;
            
            //## auto_generated 
            void setFederateType(int p_federateType);
        
        
        ////    Framework operations    ////
        public :
            
            //## auto_generated 
            void __setThePostOffice(IO::PostOffice* p_PostOffice);
            
            //## auto_generated 
            void _setThePostOffice(IO::PostOffice* p_PostOffice);
            
            //## auto_generated 
            void _clearThePostOffice();
        
        protected :
            
            //## auto_generated 
            void cleanUpRelations();
        
        
        ////    Attributes    ////
        protected :
            
            FederateFrameworkType federateFrameworkType;		//## attribute federateFrameworkType 
            
            FederateInterfaceFactory* federateInterfaceFactory;		//## attribute federateInterfaceFactory 
            
            int federateType;		//## attribute federateType 
            
        
        ////    Relations and components    ////
        protected :
            
            IO::PostOffice* thePostOffice;		//## link thePostOffice 
            
        
        
        };
    }
}


#endif  
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\Federate.h
*********************************************************************/

