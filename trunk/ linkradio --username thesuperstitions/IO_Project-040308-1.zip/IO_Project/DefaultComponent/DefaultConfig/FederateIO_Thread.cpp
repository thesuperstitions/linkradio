/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Framework::IO::FederateIO_Thread
//!	Generated Date	: Wed, 2, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\FederateIO_Thread.cpp
*********************************************************************/

#include "FederateIO_Thread.h"
// dependency Control 
#include "Control.h"
// operation FederateIO_Thread(FederateInterface*) 
#include "FederateInterface.h"
// link itsFederateIO_Handler 
#include "FederateIO_Handler.h"
// dependency PostOffice 
#include "PostOffice.h"

//----------------------------------------------------------------------------
// FederateIO_Thread.cpp                                                                  
//----------------------------------------------------------------------------

//## package Framework::IO 

//## class FederateIO_Thread 

namespace Framework {
    namespace IO {
        
        
        FederateIO_Thread::FederateIO_Thread(FederateInterface* federateInterface) : federateInterface(federateInterface) {
            itsFederateIO_Handler = NULL;
            //#[ operation FederateIO_Thread(FederateInterface*) 
            //#]
        }
        
        FederateIO_Thread::FederateIO_Thread() {
            itsFederateIO_Handler = NULL;
        }
        
        FederateIO_Thread::~FederateIO_Thread() {
            cleanUpRelations();
        }
        
        void FederateIO_Thread::addFederateMessage(FederateMessage* message) {
            //#[ operation addFederateMessage(FederateMessage*) 
            this->addItsFederateMessage(message);
            //#]
        }
        
        void FederateIO_Thread::threadOperation() {
            //#[ operation threadOperation() 
            
            FederateMessage* fm_Ptr;    
            
            while (true)
            {    
              Framework::MutexLock* myLock =  new MutexLock(myMutex);  
              try
              {
                // Check to see if there's a Federate Message in the list   
                if (itsFederateMessage.empty() != true)
                {                                        
                  // Send the message to the Post Office for delivery.
                  fm_Ptr = *itsFederateMessage.begin();  // Get the first FederateMessage in the list. 
                
                  Framework::Control::getPostOffice()->sendMessage( federateInterface, fm_Ptr);
                     
                  removeItsFederateMessage(fm_Ptr);   // Remove the just-sent FederateMessage from the list.
                }   
              } 
              catch (...)
              {
                delete myLock;
              } 
              
              delete myLock;
            //              Sleep(1);
            };  
            //#]
        }
        
        FederateInterface* FederateIO_Thread::getFederateInterface() const {
            return federateInterface;
        }
        
        void FederateIO_Thread::setFederateInterface(FederateInterface* p_federateInterface) {
            federateInterface = p_federateInterface;
        }
        
        Framework::Mutex FederateIO_Thread::getMyMutex() const {
            return myMutex;
        }
        
        void FederateIO_Thread::setMyMutex(Framework::Mutex p_myMutex) {
            myMutex = p_myMutex;
        }
        
        Framework::IO::FederateIO_Handler* FederateIO_Thread::getItsFederateIO_Handler() const {
            return itsFederateIO_Handler;
        }
        
        void FederateIO_Thread::__setItsFederateIO_Handler(Framework::IO::FederateIO_Handler* p_FederateIO_Handler) {
            itsFederateIO_Handler = p_FederateIO_Handler;
        }
        
        void FederateIO_Thread::_setItsFederateIO_Handler(Framework::IO::FederateIO_Handler* p_FederateIO_Handler) {
            if(itsFederateIO_Handler != NULL)
                {
                    itsFederateIO_Handler->__setItsFederateIO_Thread(NULL);
                }
            __setItsFederateIO_Handler(p_FederateIO_Handler);
        }
        
        void FederateIO_Thread::setItsFederateIO_Handler(Framework::IO::FederateIO_Handler* p_FederateIO_Handler) {
            if(p_FederateIO_Handler != NULL)
                {
                    p_FederateIO_Handler->_setItsFederateIO_Thread(this);
                }
            _setItsFederateIO_Handler(p_FederateIO_Handler);
        }
        
        void FederateIO_Thread::_clearItsFederateIO_Handler() {
            itsFederateIO_Handler = NULL;
        }
        
        std::vector<Framework::IO::FederateMessage*>::const_iterator FederateIO_Thread::getItsFederateMessage() const {
            std::vector<Framework::IO::FederateMessage*>::const_iterator iter;
            iter = itsFederateMessage.begin();
            return iter;
        }
        
        std::vector<Framework::IO::FederateMessage*>::const_iterator FederateIO_Thread::getItsFederateMessageEnd() const {
            return itsFederateMessage.end();
        }
        
        void FederateIO_Thread::addItsFederateMessage(Framework::IO::FederateMessage* p_FederateMessage) {
            itsFederateMessage.push_back(p_FederateMessage);
        }
        
        void FederateIO_Thread::removeItsFederateMessage(Framework::IO::FederateMessage* p_FederateMessage) {
            std::vector<Framework::IO::FederateMessage*>::iterator pos = std::find(itsFederateMessage.begin(), itsFederateMessage.end(),p_FederateMessage);
            if (pos != itsFederateMessage.end()) {
            	itsFederateMessage.erase(pos);
            }
        }
        
        void FederateIO_Thread::clearItsFederateMessage() {
            itsFederateMessage.clear();
        }
        
        void FederateIO_Thread::cleanUpRelations() {
            if(itsFederateIO_Handler != NULL)
                {
                    Framework::IO::FederateIO_Thread* p_FederateIO_Thread = itsFederateIO_Handler->getItsFederateIO_Thread();
                    if(p_FederateIO_Thread != NULL)
                        {
                            itsFederateIO_Handler->__setItsFederateIO_Thread(NULL);
                        }
                    itsFederateIO_Handler = NULL;
                }
            {
                itsFederateMessage.clear();
            }
        }
        
    }
}


/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\FederateIO_Thread.cpp
*********************************************************************/

