/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Framework::class_6
//!	Generated Date	: Fri, 15, Feb 2008  
	File Path	: DefaultComponent\DefaultConfig\class_6.cpp
*********************************************************************/

#include "class_6.h"

//----------------------------------------------------------------------------
// class_6.cpp                                                                  
//----------------------------------------------------------------------------

//## package Framework 

//## class class_6 

namespace Framework {
    
    class_6::class_6() {
    }
    
    class_6::~class_6() {
    }
    
}


/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\class_6.cpp
*********************************************************************/

