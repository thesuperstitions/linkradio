/*********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: FrameworkTest
//!	Generated Date	: Thu, 21, Feb 2008  
	File Path	: DefaultComponent\DefaultConfig\FrameworkTest.h
*********************************************************************/


#ifndef FrameworkTest_H 

#define FrameworkTest_H 

#include <oxf/oxf.h>
#include <string>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <iostream>
#include "Configuration.h"
#include "RTI\RTI1516.h"
// operation theFederateInterfaceFactory(HLA_FederateFrameworkType) 
#include "FederateInterfaceFactory.h"

//----------------------------------------------------------------------------
// FrameworkTest.h                                                                  
//----------------------------------------------------------------------------

class FrameworkTester;

//## package FrameworkTest 

#ifdef _MSC_VER
// disable Microsoft compiler warning (debug information truncated)
#pragma warning(disable: 4786)
#endif




#endif  
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\FrameworkTest.h
*********************************************************************/

