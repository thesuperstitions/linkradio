/*********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Framework::IO::FederateIO_Handler
//!	Generated Date	: Tue, 1, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\FederateIO_Handler.h
*********************************************************************/


#ifndef FederateIO_Handler_H 

#define FederateIO_Handler_H 

#include <oxf/oxf.h>
#include <string>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <iostream>
#include "Configuration.h"
#include "RTI\RTI1516.h"
#include "IO.h"
#include <map>
#include <iterator>
#include <oxf/OMValueCompare.h>
// operation FederateIO_Handler(Framework::InterfaceType,FederateFrameworkType) 
#include "Framework.h"
// link itsFederateInterface 
#include "FederateInterface.h"
// link itsFederateMessage 
#include "FederateMessage.h"
// class FederateIO_Handler 
#include "IO_Handler.h"

//----------------------------------------------------------------------------
// FederateIO_Handler.h                                                                  
//----------------------------------------------------------------------------


namespace Framework {
    
    namespace Control {
        class FederateInterfaceFactory;
        
    } 
    
namespace IO {
    class FederateIO_Thread;
    class PostOffice;
    
} 

namespace Control {
    class Serializer;
}

}


//## package Framework::IO 

#ifdef _MSC_VER
// disable Microsoft compiler warning (debug information truncated)
#pragma warning(disable: 4786)
#endif

namespace Framework {
    namespace IO {
        //## class FederateIO_Handler 
        class FederateIO_Handler : public IO_Handler {
        
        
        ////    Constructors and destructors    ////
        public :
            
            //## operation FederateIO_Handler(Framework::InterfaceType,FederateFrameworkType) 
            FederateIO_Handler(Framework::InterfaceType interfaceType, FederateFrameworkType frameworkType);
            
            //## auto_generated 
            FederateIO_Handler();
            
            //## auto_generated 
            ~FederateIO_Handler();
        
        
        ////    Operations    ////
        public :
            
            //## operation createFederateInterface(std::string) 
            void createFederateInterface(std::string interfaceName);
            
            //## operation recvMessage(FederateMessage*) 
            void recvMessage(FederateMessage* message);
            
            //## operation sendMessage(std::string,char*,int) 
            void sendMessage(std::string interfaceName, char* message, int messageSizeInBytes);
        
        
        ////    Additional operations    ////
        public :
            
            //## auto_generated 
            FederateFrameworkType getFrameworkType() const;
            
            //## auto_generated 
            void setFrameworkType(FederateFrameworkType p_frameworkType);
            
            //## auto_generated 
            Framework::InterfaceType getInterfaceType() const;
            
            //## auto_generated 
            void setInterfaceType(Framework::InterfaceType p_interfaceType);
            
            //## auto_generated 
            FederateIO_Thread* getItsFederateIO_Thread() const;
            
            //## auto_generated 
            void setItsFederateIO_Thread(FederateIO_Thread* p_FederateIO_Thread);
            
            //## auto_generated 
            std::map<std::string, FederateInterface*>::const_iterator getItsFederateInterface() const;
            
            //## auto_generated 
            std::map<std::string, FederateInterface*>::const_iterator getItsFederateInterfaceEnd() const;
            
            //## auto_generated 
            void clearItsFederateInterface();
            
            //## auto_generated 
            void removeItsFederateInterface(FederateInterface* p_FederateInterface);
            
            //## auto_generated 
            FederateInterface* getItsFederateInterface(std::string key) const;
            
            //## auto_generated 
            void addItsFederateInterface(std::string key, FederateInterface* p_FederateInterface);
            
            //## auto_generated 
            void removeItsFederateInterface(std::string key);
            
            //## auto_generated 
            Control::FederateInterfaceFactory* getItsFederateInterfaceFactory() const;
            
            //## auto_generated 
            void setItsFederateInterfaceFactory(Control::FederateInterfaceFactory* p_FederateInterfaceFactory);
            
            //## auto_generated 
            std::map<FederateInterface*, FederateMessage*>::const_iterator getItsFederateMessage() const;
            
            //## auto_generated 
            std::map<FederateInterface*, FederateMessage*>::const_iterator getItsFederateMessageEnd() const;
            
            //## auto_generated 
            void clearItsFederateMessage();
            
            //## auto_generated 
            void removeItsFederateMessage(FederateMessage* p_FederateMessage);
            
            //## auto_generated 
            FederateMessage* getItsFederateMessage(FederateInterface* key) const;
            
            //## auto_generated 
            void addItsFederateMessage(FederateInterface* key, FederateMessage* p_FederateMessage);
            
            //## auto_generated 
            void removeItsFederateMessage(FederateInterface* key);
        
        
        ////    Framework operations    ////
        public :
            
            //## auto_generated 
            void __setItsFederateIO_Thread(FederateIO_Thread* p_FederateIO_Thread);
            
            //## auto_generated 
            void _setItsFederateIO_Thread(FederateIO_Thread* p_FederateIO_Thread);
            
            //## auto_generated 
            void _clearItsFederateIO_Thread();
            
            //## auto_generated 
            void _clearItsFederateInterface();
            
            //## auto_generated 
            void _removeItsFederateInterface(FederateInterface* p_FederateInterface);
            
            //## auto_generated 
            void _addItsFederateInterface(std::string key, FederateInterface* p_FederateInterface);
            
            //## auto_generated 
            void _removeItsFederateInterface(std::string key);
        
        protected :
            
            //## auto_generated 
            void cleanUpRelations();
        
        
        ////    Attributes    ////
        protected :
            
            FederateFrameworkType frameworkType;		//## attribute frameworkType 
            
            Framework::InterfaceType interfaceType;		//## attribute interfaceType 
            
        
        ////    Relations and components    ////
        protected :
            
            FederateIO_Thread* itsFederateIO_Thread;		//## link itsFederateIO_Thread 
            
            
            std::map<std::string, FederateInterface*> itsFederateInterface;		//## link itsFederateInterface 
            
            
            Control::FederateInterfaceFactory* itsFederateInterfaceFactory;		//## link itsFederateInterfaceFactory 
            
            
            std::map<FederateInterface*, FederateMessage*> itsFederateMessage;		//## link itsFederateMessage 
            
        
        
        };
    }
}


#endif  
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\FederateIO_Handler.h
*********************************************************************/

