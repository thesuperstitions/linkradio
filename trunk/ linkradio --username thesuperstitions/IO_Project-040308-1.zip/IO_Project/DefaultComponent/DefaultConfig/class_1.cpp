/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: boost::class_1
//!	Generated Date	: Wed, 2, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\class_1.cpp
*********************************************************************/

#include "class_1.h"

//----------------------------------------------------------------------------
// class_1.cpp                                                                  
//----------------------------------------------------------------------------

//## package boost 

//## class class_1 

namespace boost {
    
    class_1::class_1() {
    }
    
    class_1::~class_1() {
    }
    
}


/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\class_1.cpp
*********************************************************************/

