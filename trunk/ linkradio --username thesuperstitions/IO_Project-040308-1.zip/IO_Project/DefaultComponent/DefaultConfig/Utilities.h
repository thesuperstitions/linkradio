/*********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Framework::Utilities
//!	Generated Date	: Fri, 15, Feb 2008  
	File Path	: DefaultComponent\DefaultConfig\Utilities.h
*********************************************************************/


#ifndef Utilities_H 

#define Utilities_H 

#include <oxf/oxf.h>
#include "Configuration.h"
#include "RTI\RTI1516.h"
#include "Framework.h"

//----------------------------------------------------------------------------
// Utilities.h                                                                  
//----------------------------------------------------------------------------

//## package Framework 


namespace Framework {
    //## class Utilities 
    class Utilities  {
    
    
    ////    Constructors and destructors    ////
    public :
        
        //## auto_generated 
        Utilities();
        
        //## auto_generated 
        ~Utilities();
    
    
    };
}


#endif  
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\Utilities.h
*********************************************************************/

