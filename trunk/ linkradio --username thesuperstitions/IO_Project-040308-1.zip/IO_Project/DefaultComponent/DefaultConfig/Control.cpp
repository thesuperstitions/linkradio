/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Framework::Control
//!	Generated Date	: Thu, 13, Mar 2008  
	File Path	: DefaultComponent\DefaultConfig\Control.cpp
*********************************************************************/

#include "Control.h"
#include "ExampleFederate.h"
#include "Federate.h"
#include "FederateInterfaceFactory.h"
#include "Serializer.h"

//----------------------------------------------------------------------------
// Control.cpp                                                                  
//----------------------------------------------------------------------------

//## package Framework::Control 

namespace Framework {
    namespace Control {
        
    }
}

namespace Framework {
    namespace Control {
        
        
        //## operation getPostOffice() 
        Framework::IO::PostOffice* getPostOffice() {
            //#[ operation getPostOffice() 
            return(NULL);
            //#]
        }
        
    }
}

/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\Control.cpp
*********************************************************************/

