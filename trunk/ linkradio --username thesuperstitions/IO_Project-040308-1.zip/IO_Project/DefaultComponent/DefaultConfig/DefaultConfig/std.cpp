/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: std
//!	Generated Date	: Fri, 15, Feb 2008  
	File Path	: DefaultComponent\DefaultConfig\DefaultConfig\std.cpp
*********************************************************************/

#include "DefaultConfig\std.h"

//----------------------------------------------------------------------------
// DefaultConfig\std.cpp                                                                  
//----------------------------------------------------------------------------

//## package ReverseEngineering::std 

namespace std {
    
}

namespace std {
    
    
}

/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\DefaultConfig\std.cpp
*********************************************************************/

