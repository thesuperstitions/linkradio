/*********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: std
//!	Generated Date	: Fri, 15, Feb 2008  
	File Path	: DefaultComponent\DefaultConfig\DefaultConfig\std.h
*********************************************************************/


#ifndef DefaultConfig_std_H 

#define DefaultConfig_std_H 

#include <oxf/oxf.h>
#include "Configuration.h"
#include "RTI\RTI1516.h"
#include "ReverseEngineering.h"

//----------------------------------------------------------------------------
// DefaultConfig\std.h                                                                  
//----------------------------------------------------------------------------

//## package ReverseEngineering::std 


namespace std {
    
    
    
}


#endif  
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\DefaultConfig\std.h
*********************************************************************/

