/*********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Mutex
//!	Generated Date	: Wed, 2, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\Mutex.h
*********************************************************************/


#ifndef Mutex_H 

#define Mutex_H 

// dependency mutex 
#include "boost\thread\mutex.hpp"

//----------------------------------------------------------------------------
// Mutex.h                                                                  
//----------------------------------------------------------------------------



#endif  
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\Mutex.h
*********************************************************************/

