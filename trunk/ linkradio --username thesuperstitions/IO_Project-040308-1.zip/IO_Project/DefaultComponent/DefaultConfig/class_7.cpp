/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Framework::class_7
//!	Generated Date	: Fri, 15, Feb 2008  
	File Path	: DefaultComponent\DefaultConfig\class_7.cpp
*********************************************************************/

#include "class_7.h"

//----------------------------------------------------------------------------
// class_7.cpp                                                                  
//----------------------------------------------------------------------------

//## package Framework 

//## class class_7 

namespace Framework {
    
    class_7::class_7() {
    }
    
    class_7::~class_7() {
    }
    
}


/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\class_7.cpp
*********************************************************************/

