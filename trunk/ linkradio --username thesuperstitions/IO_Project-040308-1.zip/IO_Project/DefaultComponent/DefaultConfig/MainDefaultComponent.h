/*********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: DefaultConfig
//!	Generated Date	: Tue, 19, Feb 2008  
	File Path	: DefaultComponent\DefaultConfig\MainDefaultComponent.h
*********************************************************************/


#ifndef MainDefaultComponent_H 

#define MainDefaultComponent_H 

#include <oxf/oxf.h>
#include <string>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <iostream>
#include "Configuration.h"
#include "RTI\RTI1516.h"

//----------------------------------------------------------------------------
// MainDefaultComponent.h                                                                  
//----------------------------------------------------------------------------



#endif  
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\MainDefaultComponent.h
*********************************************************************/

