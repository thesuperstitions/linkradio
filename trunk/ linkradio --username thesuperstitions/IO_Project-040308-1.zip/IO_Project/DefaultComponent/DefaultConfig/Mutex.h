/*********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Framework::Mutex
//!	Generated Date	: Wed, 2, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\Mutex.h
*********************************************************************/


#ifndef Mutex_H 

#define Mutex_H 

#include <oxf/oxf.h>
#include <string>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <iostream>
#include "Configuration.h"
#include "RTI\RTI1516.h"
#include "Framework.h"

//----------------------------------------------------------------------------
// Mutex.h                                                                  
//----------------------------------------------------------------------------

//## package Framework 

#ifdef _MSC_VER
// disable Microsoft compiler warning (debug information truncated)
#pragma warning(disable: 4786)
#endif

namespace Framework {
    // wrapper for a generic mutex. 
    // currently we use the boost mutex.
    //## class Mutex 
    class Mutex  {
    
    
    ////    Friends    ////
    public :
        
        friend  class Framework::MutexLock;
    
    
    ////    Constructors and destructors    ////
    public :
        
        //## operation Mutex() 
        Mutex() {
            //#[ operation Mutex() 
            //#]
        }
        
        
        //## operation ~Mutex() 
        ~Mutex() {
            //#[ operation ~Mutex() 
            //#]
        }
        
    
    protected :
        
        //## operation Mutex(const Mutex &) 
        Mutex(const Mutex & arg1);
    
    
    ////    Operations    ////
    protected :
        
        //## operation operator=(const Mutex &) 
        Mutex &  operator=(const Mutex & arg1);
    
    
    ////    Attributes    ////
    private :
        
        boost::mutex mutex;		//## attribute mutex 
        
    
    };
}


#endif  
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\Mutex.h
*********************************************************************/

