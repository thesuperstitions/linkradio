/*********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: FrameworkSingletons
//!	Generated Date	: Wed, 20, Feb 2008  
	File Path	: DefaultComponent\DefaultConfig\FrameworkSingletons.h
*********************************************************************/


#ifndef FrameworkSingletons_H 

#define FrameworkSingletons_H 

#include <oxf/oxf.h>
#include <string>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <iostream>
#include "Configuration.h"
#include "RTI\RTI1516.h"
// attribute theFrameworkFederateAmbassador 
#include "FrameworkFederateAmbassador.h"

//----------------------------------------------------------------------------
// FrameworkSingletons.h                                                                  
//----------------------------------------------------------------------------

//## package FrameworkSingletons 

#ifdef _MSC_VER
// disable Microsoft compiler warning (debug information truncated)
#pragma warning(disable: 4786)
#endif


//## auto_generated 
static FrameworkFederateAmbassador getTheFrameworkFederateAmbassador();

//## auto_generated 
static void setTheFrameworkFederateAmbassador(FrameworkFederateAmbassador p_theFrameworkFederateAmbassador);



#endif  
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\FrameworkSingletons.h
*********************************************************************/

