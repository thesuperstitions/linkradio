/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Framework::utils
//!	Generated Date	: Wed, 2, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\utils.cpp
*********************************************************************/

#include "utils.h"
#include "utils\Thread.h"

//----------------------------------------------------------------------------
// utils.cpp                                                                  
//----------------------------------------------------------------------------

//## package Framework::utils 

namespace Framework {
    namespace utils {
        
    }
}

namespace Framework {
    namespace utils {
        
        
        
    }
}

/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\utils.cpp
*********************************************************************/

