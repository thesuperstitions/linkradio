/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Framework::Control::RTI_Ambassador
//!	Generated Date	: Fri, 15, Feb 2008  
	File Path	: DefaultComponent\DefaultConfig\RTI_Ambassador.cpp
*********************************************************************/

#include "RTI_Ambassador.h"

//----------------------------------------------------------------------------
// RTI_Ambassador.cpp                                                                  
//----------------------------------------------------------------------------

//## package Framework::Control 

//## class RTI_Ambassador 

namespace Framework {
    namespace Control {
        
        RTI_Ambassador::RTI_Ambassador() {
        }
        
        RTI_Ambassador::~RTI_Ambassador() {
        }
        
        void RTI_Ambassador::publishInteractionClass(rti1516::InteractionClassHandle handle) {
            //#[ operation publishInteractionClass(rti1516::InteractionClassHandle) 
            //#]
        }
        
    }
}


/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\RTI_Ambassador.cpp
*********************************************************************/

