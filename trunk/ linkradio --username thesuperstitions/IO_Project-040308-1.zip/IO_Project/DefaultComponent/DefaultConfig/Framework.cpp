/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Framework
//!	Generated Date	: Wed, 2, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\Framework.cpp
*********************************************************************/

#include "Framework.h"
// operation getFrameworkFederateAmbassador() 
#include "FrameworkFederateAmbassador.h"
#include "BoostThreadWrappers\Mutex.h"
#include "BoostThreadWrappers\MutexLock.h"
#include "RtiAmbassador.h"
#include "BoostThreadWrappers\Thread.h"

//----------------------------------------------------------------------------
// Framework.cpp                                                                  
//----------------------------------------------------------------------------

//## package Framework 

namespace Framework {
    
}

namespace Framework {
    
    
    //## operation RealTimeMode() 
    bool RealTimeMode() {
        //#[ operation RealTimeMode() 
        return(true);
        //#]
    }
    
    //## operation getFrameworkFederateAmbassador() 
    FrameworkFederateAmbassador* getFrameworkFederateAmbassador() {
        //#[ operation getFrameworkFederateAmbassador() 
        return(NULL);
        //#]
    }
    
    //## operation getTheRtiAmbassador() 
    rti1516::RTIambassador* getTheRtiAmbassador() {
        //#[ operation getTheRtiAmbassador() 
        return(NULL);
        //#]
    }
    
}

/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\Framework.cpp
*********************************************************************/

