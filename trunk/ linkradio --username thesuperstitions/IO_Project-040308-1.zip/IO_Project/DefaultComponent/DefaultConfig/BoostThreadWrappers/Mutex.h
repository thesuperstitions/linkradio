/*********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: __MUTEX__H
//!	Generated Date	: Wed, 2, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\BoostThreadWrappers\Mutex.h
*********************************************************************/


#ifndef BoostThreadWrappers_Mutex_H 

#define BoostThreadWrappers_Mutex_H 

// dependency mutex 
#include "boost\thread\mutex.hpp"
#include <string>
#include <sstream>
#include <iomanip>
#include <iostream>
#include "Configuration.h"
#include "RTI\RTI1516.h"
#include <oxf/oxf.h>
#include <algorithm>
#include "Framework.h"

//----------------------------------------------------------------------------
// BoostThreadWrappers\Mutex.h                                                                  
//----------------------------------------------------------------------------

//## attribute ::ReverseEngineering::TopLevel.__MUTEX__H 
#define __MUTEX__H 
//## package Framework 

#ifdef _MSC_VER
// disable Microsoft compiler warning (debug information truncated)
#pragma warning(disable: 4786)
#endif

namespace Framework {
    // wrapper for a generic mutex. 
    // currently we use the boost mutex.
    //## class Mutex 
    class Mutex  {
    
    
    ////    Friends    ////
    public :
        
        friend  class Framework::MutexLock;
    
    
    ////    Constructors and destructors    ////
    public :
        
        //## operation Mutex() 
        Mutex() {
            //#[ operation Mutex() 
            //#]
        }
        
        
        //## operation ~Mutex() 
        ~Mutex() {
            //#[ operation ~Mutex() 
            //#]
        }
        
    
    protected :
        
        //## operation Mutex(const Mutex &) 
        Mutex(const Mutex & arg1);
    
    
    ////    Operations    ////
    protected :
        
        //## operation operator=(const Mutex &) 
        Mutex &  operator=(const Mutex & arg1);
    
    
    ////    Attributes    ////
    private :
        
        boost::mutex mutex;		//## attribute mutex 
        
    
    };
}
//## package Framework 

//## class Mutex 

namespace Framework {
    
    
    
}



#endif  
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\BoostThreadWrappers\Mutex.h
*********************************************************************/

