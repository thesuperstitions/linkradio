/*********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Framework::class_6
//!	Generated Date	: Fri, 15, Feb 2008  
	File Path	: DefaultComponent\DefaultConfig\class_6.h
*********************************************************************/


#ifndef class_6_H 

#define class_6_H 

#include <oxf/oxf.h>
#include "Configuration.h"
#include "RTI\RTI1516.h"
#include "Framework.h"

//----------------------------------------------------------------------------
// class_6.h                                                                  
//----------------------------------------------------------------------------

//## package Framework 


namespace Framework {
    //## class class_6 
    class class_6  {
    
    
    ////    Constructors and destructors    ////
    public :
        
        //## auto_generated 
        class_6();
        
        //## auto_generated 
        ~class_6();
    
    
    };
}


#endif  
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\class_6.h
*********************************************************************/

