/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: FrameworkTest
//!	Generated Date	: Thu, 21, Feb 2008  
	File Path	: DefaultComponent\DefaultConfig\FrameworkTest.cpp
*********************************************************************/

#include "FrameworkTest.h"
#include "FrameworkTester.h"

//----------------------------------------------------------------------------
// FrameworkTest.cpp                                                                  
//----------------------------------------------------------------------------

//## package FrameworkTest 


//## operation theFederateInterfaceFactory(HLA_FederateFrameworkType) 
static FederateInterfaceFactory theFederateInterfaceFactory(HLA_FederateFrameworkType arg1);

//## operation theFederateInterfaceFactory(HLA_FederateFrameworkType) 
static FederateInterfaceFactory theFederateInterfaceFactory(HLA_FederateFrameworkType arg1) {
    //#[ operation theFederateInterfaceFactory(HLA_FederateFrameworkType) 
    //#]
}


/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\FrameworkTest.cpp
*********************************************************************/

