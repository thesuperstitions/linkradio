/********************************************************************
	Rhapsody	: 7.1 
	Login		: rosskw1
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Framework::MutexLock
//!	Generated Date	: Wed, 2, Apr 2008  
	File Path	: DefaultComponent\DefaultConfig\MutexLock.cpp
*********************************************************************/

#include "MutexLock.h"
// operation MutexLock(Mutex &) 
#include "BoostThreadWrappers\Mutex.h"

//----------------------------------------------------------------------------
// MutexLock.cpp                                                                  
//----------------------------------------------------------------------------

//## package Framework 

//## class MutexLock 

namespace Framework {
    
    
    
}


/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\MutexLock.cpp
*********************************************************************/

